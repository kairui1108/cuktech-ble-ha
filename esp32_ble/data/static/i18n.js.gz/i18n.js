/* i18n.js — 轻量客户端国际化引擎（ESP32 内嵌前端专用，零依赖、无网络请求）
 *
 * 语言资源文件（须在本文件之前加载）:
 *   /static/lang/zh.js  -> window.I18N_ZH  (简体中文, 翻译回退源)
 *   /static/lang/en.js  -> window.I18N_EN  (English, 默认/兜底显示语言)
 *
 * 语言生效顺序: localStorage['cuktech-lang'] -> navigator.language -> en
 * 自适应规则:   浏览器语言 zh-* -> 中文；其余语言（含无法识别）-> 英文
 * 回退链:       当前语言 -> zh-CN（翻译回退源）-> 键名本身
 *
 * API:
 *   I18N.t(key, params)        取文案；params 支持 {n} 等占位符；
 *                              值为 {one, other} 对象时按 n 自动复数
 *   I18N.num(n, digits?)       数字本地化（Intl 不可用时回退 toString）
 *   I18N.apply()               将 data-i18n / data-i18n-placeholder /
 *                              data-i18n-title 应用到当前 DOM，并通知监听器
 *   I18N.setLang('en')         切换语言并持久化到 localStorage
 *   I18N.toggle()              中/英 切换（如需导航栏按钮）
 *   I18N.onChange(fn)          注册语言切换后的动态重渲染回调
 *   I18N.getLang()             当前语言代码 ('zh-CN' | 'en')
 */
(function () {
    'use strict';
    var STORAGE_KEY = 'cuktech-lang';
    var DEFAULT_LANG = 'en';      /* 默认/兜底显示语言（浏览器语言无法识别时） */
    var FALLBACK_LANG = 'zh-CN';  /* 翻译回退源（某键缺失时从此语言补） */
    var SUPPORTED = { 'zh-CN': true, 'en': true };

    var dicts = {
        'zh-CN': window.I18N_ZH || {},
        'en': window.I18N_EN || {}
    };

    /* 浏览器语言 -> 受支持语言代码（zh/zh-CN/zh-Hans -> zh-CN, en/en-US -> en） */
    function normalize(raw) {
        if (!raw) return null;
        var s = String(raw).toLowerCase().replace(/_/g, '-');
        if (s.indexOf('zh') === 0) return 'zh-CN';
        if (s.indexOf('en') === 0) return 'en';
        return null;
    }

    function detect() {
        var saved = null;
        try { saved = localStorage.getItem(STORAGE_KEY); } catch (e) {}
        var n = normalize(saved);
        if (n && SUPPORTED[n]) return n;
        var nav = '';
        try { nav = navigator.language || navigator.userLanguage || ''; } catch (e) {}
        n = normalize(nav);
        return (n && SUPPORTED[n]) ? n : DEFAULT_LANG;
    }

    var current = detect();

    /* 按点号路径取字典值（支持嵌套对象） */
    function lookup(key, lang) {
        var obj = dicts[lang];
        var parts = String(key).split('.');
        for (var i = 0; i < parts.length; i++) {
            if (obj == null || typeof obj !== 'object') return undefined;
            obj = obj[parts[i]];
        }
        return obj;
    }

    /* 解析带回退的条目值 */
    function resolve(key) {
        var v = lookup(key, current);
        if (v === undefined && current !== FALLBACK_LANG) v = lookup(key, FALLBACK_LANG);
        if (v === undefined) return String(key);
        return v;
    }

    /* {name} 占位符替换 */
    function fill(tpl, params) {
        if (!params) return tpl;
        return tpl.replace(/\{(\w+)\}/g, function (m, name) {
            var val = params[name];
            return (val === undefined || val === null) ? m : String(val);
        });
    }

    /* 取文案；值为 {one, other} 时按 params.n 复数化 */
    function t(key, params) {
        var v = resolve(key);
        if (typeof v === 'string') return fill(v, params);
        if (v && typeof v === 'object') {
            var n = (params && params.n !== undefined) ? Number(params.n) : 1;
            var s = v[n === 1 ? 'one' : 'other'];
            if (typeof s !== 'string') s = v.other;
            if (typeof s === 'string') return fill(s, params);
        }
        return String(key);
    }

    /* 数字本地化（示例能力；当前界面功率/电压等均为 locale 中性，未强制使用） */
    function num(n, digits) {
        try {
            var opts = {};
            if (digits !== undefined) {
                opts.minimumFractionDigits = digits;
                opts.maximumFractionDigits = digits;
            }
            return new Intl.NumberFormat(current === 'zh-CN' ? 'zh-CN' : 'en', opts).format(n);
        } catch (e) {
            return String(n);
        }
    }

    var listeners = [];

    /* 将当前语言应用到页面：data-i18n 文本、placeholder、title、<html lang>、切换按钮 */
    function apply(root) {
        root = root || document;
        var html = document.documentElement;
        if (html) html.setAttribute('lang', current === 'zh-CN' ? 'zh-CN' : 'en');

        var btn = document.getElementById('langBtn');
        if (btn) {
            btn.textContent = current === 'zh-CN' ? 'EN' : '中';
            var tip = lookup('lang.btnTitle', current);
            if (typeof tip !== 'string' && current !== FALLBACK_LANG) tip = lookup('lang.btnTitle', FALLBACK_LANG);
            if (typeof tip === 'string') btn.setAttribute('title', tip);
        }

        var i, el, key;
        var texts = root.querySelectorAll('[data-i18n]');
        for (i = 0; i < texts.length; i++) {
            el = texts[i];
            key = el.getAttribute('data-i18n');
            if (key) el.textContent = t(key);
        }
        var phs = root.querySelectorAll('[data-i18n-placeholder]');
        for (i = 0; i < phs.length; i++) {
            el = phs[i];
            key = el.getAttribute('data-i18n-placeholder');
            if (key) el.setAttribute('placeholder', t(key));
        }
        var tis = root.querySelectorAll('[data-i18n-title]');
        for (i = 0; i < tis.length; i++) {
            el = tis[i];
            key = el.getAttribute('data-i18n-title');
            if (key) el.setAttribute('title', t(key));
        }

        /* 通知动态渲染监听器（JS 生成的文本按语言重渲染） */
        for (i = 0; i < listeners.length; i++) {
            try { listeners[i](current); } catch (e) {}
        }
    }

    /* 设置语言；lang='auto' 表示跟随浏览器（先清除手动选择，再按 navigator.language 探测） */
    function setLang(lang) {
        if (lang === 'auto') {
            try { localStorage.setItem(STORAGE_KEY, 'auto'); } catch (e) {}
            current = detect();   /* 'auto' 记录被视作无手动选择，回退走浏览器语言 */
            apply();
            return;
        }
        var n = normalize(lang);
        current = (n && SUPPORTED[n]) ? n : DEFAULT_LANG;
        try { localStorage.setItem(STORAGE_KEY, current); } catch (e) {}
        apply();
    }

    function toggle() {
        setLang(current === 'zh-CN' ? 'en' : 'zh-CN');
    }

    function onChange(fn) {
        if (typeof fn === 'function') listeners.push(fn);
    }

    window.I18N = {
        t: t,
        num: num,
        apply: apply,
        setLang: setLang,
        toggle: toggle,
        onChange: onChange,
        getLang: function () { return current; },
        STORAGE_KEY: STORAGE_KEY
    };

    /* 页面就绪后应用语言（静态文案 + 通知监听器） */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { apply(); });
    } else {
        apply();
    }
})();

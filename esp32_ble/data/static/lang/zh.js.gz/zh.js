/* 简体中文语言资源 (zh-CN) —— ESP32 内嵌前端默认语言 & 回退语言
 * 由 i18n.js 加载；键名结构: <页面>.<组件>.<条目>
 * 值可为字符串，或 {one, other} 复数对象（配合 t(key, {n}) 使用）
 * 说明: 品牌名/专有名词（CUKTECH、PD/PPS/UFCS/SCP、C1/C2/C3/USB-A、MAC、Token 等）不放入字典；
 *       巴法云设备默认名（C口1开关 等）属于业务数据（写入云端/小爱同学），保持中文不翻译。 */
window.I18N_ZH = {
  "phone": {
    "title": "CUKTECH 10 Ultra 充电器"
  },
  "status": {
    "connected": "已连接",
    "disconnected": "未连接",
    "connect": "连接设备",
    "disconnect": "断开设备",
    "connecting": "连接中...",
    "disconnecting": "断开中..."
  },
  "toast": {
    "connecting": "正在连接设备，请稍候..."
  },
  "scene": {
    "title": "场景模式",
    "ai": "AI模式",
    "eco": "数码生态",
    "single": "单口模式",
    "balance": "均衡模式"
  },
  "sceneDesc": {
    "ai": "自动识别设备智能匹配最优充电功率",
    "eco": "多口同时充电均衡分配功率",
    "single": "单口最大功率输出优先C1口",
    "balance": "多个端口均衡分配充电功率"
  },
  "port": {
    "title": "端口控制"
  },
  "screen": {
    "title": "息屏时间",
    "time1": "1分钟",
    "time5": "5分钟",
    "time10": "10分钟",
    "time30": "30分钟",
    "always": "常亮"
  },
  "trickle": {
    "title": "USB-A小电流"
  },
  "rate": {
    "totalTitle": "当前总功率",
    "currentLabel": "当前功率",
    "chartTitle": "功率曲线",
    "distTitle": "功率占比"
  },
  "delay": {
    "title": "延时关闭",
    "none": "未设置",
    "minutes": "{n}分钟",
    "noActivePorts": "暂无活跃端口"
  },
  "proto": {
    "pdNote": "关闭PD后PPS也将关闭",
    "replugNote": "需重新插拔端口"
  },
  "mem": {
    "label": "MEM"
  },
  "lang": {
    "btnTitle": "切换语言 / Switch Language"
  },
  "config": {
    "title": "CUKTECH 配置",
    "navTitle": "系统配置",
    "wifi": {
      "section": "WiFi 网络",
      "ssid": "WiFi 名称",
      "ssidHint": "2.4GHz 无线网络 SSID",
      "ssidPh": "WiFi SSID",
      "pass": "WiFi 密码",
      "passHint": "无线网络密码",
      "passPh": "WiFi 密码"
    },
    "ble": {
      "section": "BLE 配置",
      "xiaomi": "小米云自动获取 ↗",
      "mac": "MAC 地址",
      "macHint": "充电器蓝牙 MAC 地址",
      "token": "Token",
      "tokenHint": "设备认证 Token",
      "tokenPh": "Token",
      "key": "BLE Key",
      "keyHint": "加密密钥",
      "keyPh": "BLE Key"
    },
    "mqtt": {
      "section": "MQTT (Home Assistant)",
      "enabled": "启用 MQTT",
      "host": "服务器",
      "hostHint": "MQTT Broker 地址",
      "port": "端口",
      "username": "用户名",
      "password": "密码",
      "topic": "Topic 前缀",
      "topicHint": "MQTT 主题前缀"
    },
    "optional": "可选",
    "bemfa": {
      "section": "巴法云",
      "register": "注册获取私钥 ↗",
      "enabled": "启用巴法云",
      "uid": "私钥",
      "uidHint": "巴法云用户 私钥",
      "uidPh": "巴法云 私钥",
      "nameC1": "C1 端口名称",
      "nameC2": "C2 端口名称",
      "nameC3": "C3 端口名称",
      "nameA": "USB-A 端口名称",
      "nameBle": "蓝牙状态名称",
      "nameHint": "巴法云设备显示名",
      "nameC1Ph": "C口1开关",
      "nameC2Ph": "C口2开关",
      "nameC3Ph": "C口3开关",
      "nameAPh": "USB-A开关",
      "nameBlePh": "蓝牙开关"
    },
    "reboot": {
      "section": "定时重启",
      "interval": "重启间隔（秒）",
      "disabledPh": "0 = 禁用",
      "presets": "快捷预设",
      "hint": "设备运行满该时长后自动重启，0 表示禁用。用于缓解长期运行的堆碎片等问题。点击上方预设可自动填入对应秒数（12h/24h/36h/48h）。"
    },
    "status": {
      "section": "当前状态",
      "loading": "加载中...",
      "loaded": "配置已加载",
      "loadError": "加载失败: "
    },
    "lang": {
      "section": "显示",
      "label": "界面语言",
      "auto": "跟随系统",
      "hint": "仅保存在本浏览器，即时生效"
    },
    "save": "保存配置并重启",
    "saving": "保存中...",
    "savedToast": "配置已保存，设备正在重启...",
    "saveFailed": "保存失败: ",
    "unknownError": "未知错误",
    "networkError": "网络错误: "
  }
};

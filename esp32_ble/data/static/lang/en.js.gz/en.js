/* English language resources (en) —— ESP32 embedded frontend
 * Loaded by i18n.js; key structure: <page>.<component>.<item>
 * Values are plain strings or {one, other} plural objects (used with t(key, {n})).
 * Notes: brand names / technical terms (CUKTECH, PD/PPS/UFCS/SCP, C1/C2/C3/USB-A,
 *        MAC, Token, ...) stay out of the dictionary; Bemfa device default names
 *        (C口1开关 etc.) are business data written to the cloud (XiaoAi) and stay
 *        in Chinese on purpose. Missing keys fall back to zh-CN. */
window.I18N_EN = {
  "phone": {
    "title": "CUKTECH 10 Ultra Charger"
  },
  "status": {
    "connected": "Connected",
    "disconnected": "Not Connected",
    "connect": "Connect",
    "disconnect": "Disconnect",
    "connecting": "Connecting...",
    "disconnecting": "Disconnecting..."
  },
  "toast": {
    "connecting": "Connecting to device, please wait..."
  },
  "scene": {
    "title": "Scene Mode",
    "ai": "AI Mode",
    "eco": "Digital Ecosystem",
    "single": "Single Port",
    "balance": "Balanced"
  },
  "sceneDesc": {
    "ai": "Auto-detects your device and matches the optimal charging power",
    "eco": "Multiple ports charging simultaneously with balanced power",
    "single": "Maximum power output from a single port, prioritizing C1",
    "balance": "Balanced power distribution across all ports"
  },
  "port": {
    "title": "Port Control"
  },
  "screen": {
    "title": "Screen-Off Time",
    "time1": "1 min",
    "time5": "5 min",
    "time10": "10 min",
    "time30": "30 min",
    "always": "Always On"
  },
  "trickle": {
    "title": "USB-A Low Current"
  },
  "rate": {
    "totalTitle": "Total Power",
    "currentLabel": "Current Power",
    "chartTitle": "Power Chart",
    "distTitle": "Power Share"
  },
  "delay": {
    "title": "Delayed Off",
    "none": "Not Set",
    "minutes": { "one": "{n} minute", "other": "{n} minutes" },
    "noActivePorts": "No active ports"
  },
  "proto": {
    "pdNote": "Disabling PD also disables PPS",
    "replugNote": "Re-plug the port to apply"
  },
  "mem": {
    "label": "MEM"
  },
  "lang": {
    "btnTitle": "Switch language / 切换语言"
  },
  "config": {
    "title": "CUKTECH Settings",
    "navTitle": "System Settings",
    "wifi": {
      "section": "WiFi Network",
      "ssid": "WiFi Name",
      "ssidHint": "2.4GHz wireless network SSID",
      "ssidPh": "WiFi SSID",
      "pass": "WiFi Password",
      "passHint": "Wireless network password",
      "passPh": "WiFi Password"
    },
    "ble": {
      "section": "BLE Configuration",
      "xiaomi": "Get from Xiaomi Cloud ↗",
      "mac": "MAC Address",
      "macHint": "Charger BLE MAC address",
      "token": "Token",
      "tokenHint": "Device authentication token",
      "tokenPh": "Token",
      "key": "BLE Key",
      "keyHint": "Encryption key",
      "keyPh": "BLE Key"
    },
    "mqtt": {
      "section": "MQTT (Home Assistant)",
      "enabled": "Enable MQTT",
      "host": "Server",
      "hostHint": "MQTT broker address",
      "port": "Port",
      "username": "Username",
      "password": "Password",
      "topic": "Topic Prefix",
      "topicHint": "MQTT topic prefix"
    },
    "optional": "optional",
    "bemfa": {
      "section": "Bemfa Cloud",
      "register": "Register to get private key ↗",
      "enabled": "Enable Bemfa Cloud",
      "uid": "Private Key",
      "uidHint": "Bemfa Cloud user private key",
      "uidPh": "Bemfa private key",
      "nameC1": "C1 Port Name",
      "nameC2": "C2 Port Name",
      "nameC3": "C3 Port Name",
      "nameA": "USB-A Port Name",
      "nameBle": "BLE Status Name",
      "nameHint": "Device name shown in Bemfa Cloud",
      "nameC1Ph": "C1 switch",
      "nameC2Ph": "C2 switch",
      "nameC3Ph": "C3 switch",
      "nameAPh": "USB-A switch",
      "nameBlePh": "BLE switch"
    },
    "reboot": {
      "section": "Scheduled Reboot",
      "interval": "Reboot interval (seconds)",
      "disabledPh": "0 = disabled",
      "presets": "Quick Presets",
      "hint": "The device reboots automatically after running for this duration; 0 disables it. Helps mitigate heap fragmentation from long uptime. Tap a preset above to auto-fill the seconds (12h/24h/36h/48h)."
    },
    "status": {
      "section": "Current Status",
      "loading": "Loading...",
      "loaded": "Configuration loaded",
      "loadError": "Failed to load: "
    },
    "lang": {
      "section": "Display",
      "label": "Interface Language",
      "auto": "Follow System",
      "hint": "Applies instantly, stored in this browser only"
    },
    "save": "Save & Reboot",
    "saving": "Saving...",
    "savedToast": "Configuration saved, device rebooting...",
    "saveFailed": "Save failed: ",
    "unknownError": "Unknown error",
    "networkError": "Network error: "
  }
};
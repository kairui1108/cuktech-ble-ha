// ── API & Config ──
const API_BASE = window.location.origin;
// i18n: 场景名/描述/息屏时间等动态文案统一走 I18N.t()（见 static/lang/zh.js, en.js）
const SCENE_NAMES = { 1: 'scene.ai', 2: 'scene.eco', 3: 'scene.single', 4: 'scene.balance' };

// Update HTML overlay lines on the combined chart using chart's scale positions
function drawPeakLines(chart) {
    try {
        var d = chart && chart._peakData;
        if (!d) return;
        var ys = chart.scales && chart.scales.y;
        if (!ys) return;
        
        var container = chart.canvas && chart.canvas.parentNode;
        if (!container) return;
        var el0w = document.getElementById('chartLines0W');
        var elPeak = document.getElementById('chartLinesPeak');
        var elLabel = document.getElementById('chartLinesLabel');
        if (!el0w || !elPeak || !elLabel) return;
        
        var zeroY = Math.round(ys.getPixelForValue(0));
        var peakY = Math.round(ys.getPixelForValue(d.peakPower));
        var isDark = d.isDark;
        
        // 0W line at bottom
        el0w.style.top = zeroY + 'px';
        el0w.style.borderTopColor = isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.2)';
        el0w.style.display = 'block';
        
        // Peak line
        if (peakY < zeroY - 4) {
            elPeak.style.top = peakY + 'px';
            elPeak.style.display = 'block';
            elLabel.textContent = Math.round(d.currentPeak) + 'W';
            elLabel.style.display = 'block';
            elLabel.style.top = (peakY - 8) + 'px';
            elLabel.style.right = '4px';
        } else {
            elPeak.style.display = 'none';
            elLabel.style.display = 'none';
        }
    } catch(e) {}
}
const SCENE_IMAGES = { 1: 'ai', 2: 'apple', 3: 'single', 4: 'balance' };
const SCENE_BTN_IMAGES = { 1: 'ai', 2: 'mac', 3: 'single', 4: 'balance' };
const SCENE_DESCS = {
    1: 'sceneDesc.ai',
    2: 'sceneDesc.eco',
    3: 'sceneDesc.single',
    4: 'sceneDesc.balance',
};
const SCENE_PIID = 5;
// 下标即原始设备值(1-5)，index 0 为占位；值均为 i18n 键
const SCREEN_TIMES = ['', 'screen.time5', 'screen.time10', 'screen.time30', 'screen.always', 'screen.time1'];
const PORT_KEYS = ['c1', 'c2', 'c3', 'a'];
const PORT_NAMES = { c1: 'C1', c2: 'C2', c3: 'C3', a: 'USB-A' };
const PORT_COLORS = { c1: '#FF7A00', c2: '#46B4FF', c3: '#89D8F3', a: '#FFD24B' };
const API_PORT_MAP = { 1: 'c1', 2: 'c2', 3: 'c3', 4: 'a' };

// ── i18n helpers ──
function sceneName(m) { return I18N.t(SCENE_NAMES[m] || 'scene.ai'); }
function sceneDesc(m) { return SCENE_DESCS[m] ? I18N.t(SCENE_DESCS[m]) : ''; }
function screenTimeLabel(i) { return I18N.t(SCREEN_TIMES[i] || ''); }

// ── State ──
let lastLocalChange = 0;
function markLocalChange() { lastLocalChange = Date.now(); }
function isRecentLocal() { return Date.now() - lastLocalChange < 3000; }
let state = {
    scene: 1,
    screenTime: 1,
    bleConnected: false,
    ports: { c1:{v:0,a:0,w:0,protocol:'idle',enabled:true}, c2:{v:0,a:0,w:0,protocol:'idle',enabled:true}, c3:{v:0,a:0,w:0,protocol:'idle',enabled:true}, a:{v:0,a:0,w:0,protocol:'idle',enabled:true} },
    settings: {},
    firmware: '',
    trickleEnabled: false,
    history: { c1: [], c2: [], c3: [], a: [] },
    protocolSwitches: {},
    protocolExtend: 0,
};

// ── API Fetch ──
async function fetchStatus() {
    try {
        // ESP32 backend: separate endpoints for status, ports, settings
        const res = await fetch(`${API_BASE}/api/all`);
        const data = await res.json();

        state.bleConnected = data.connected && data.authenticated;
        state.firmware = data.firmware_version || '';

        // Ports: array [c1, c2, c3, a]
        if (Array.isArray(data.ports)) {
            data.ports.forEach((port, idx) => {
                const key = ['c1','c2','c3','a'][idx];
                if (key && state.ports[key]) {
                    state.ports[key].v = port.voltage || 0;
                    state.ports[key].a = port.current || 0;
                    state.ports[key].w = port.power || 0;
                    if (!isRecentLocal()) state.ports[key].enabled = port.active !== false;
                    state.ports[key].protocol = port.protocol || 'idle';
                    state.ports[key].status_raw = port.status;
                }
            });
        }

        // Settings: flat object with PIID keys
        if (data.settings) {
            state.settings = data.settings;
            const sceneVal = data.settings['5'];
            if (sceneVal && sceneVal > 0 && !isRecentLocal()) state.scene = sceneVal;
            if (!isRecentLocal()) {
                if (data.settings['6'] !== undefined) state.screenTime = data.settings['6'];
                if (data.settings['15'] !== undefined) state.trickleEnabled = data.settings['15'] === 1;
            }
            if (!isRecentLocal()) {
                for (const key of PORT_KEYS) {
                    const v = data.settings[String(DELAY_PIIDS[key])];
                    if (v !== undefined) delayMinutes[key] = parseInt(v) || 0;
                }
            }
            // Parse protocol switches from PIID 21 bitmask
            const protoVal = data.settings['21'] || 0;
            state.protocolExtend = protoVal;
            const PROTO_BITS = {
                c1: { pd: 0, pps: 1, ufcs: 2 },
                c2: { pd: 8, pps: 9, ufcs: 10 },
                c3: { ufcs: 16, scp: 17 },
                a:  { ufcs: 24, scp: 25 }
            };
            for (const key of PORT_KEYS) {
                const bits = PROTO_BITS[key];
                if (!bits) continue;
                const sw = {};
                for (const [name, bit] of Object.entries(bits)) sw[name] = !!(protoVal & (1 << bit));
                state.protocolSwitches[key] = sw;
            }
            // Parse port enable state from PIID 16 bitmask
            const portCtrl = data.settings['16'] || 0;
            const PORT_IDXS = { c1: 0, c2: 1, c3: 2, a: 3 };
            for (const key of PORT_KEYS) {
                if (!isRecentLocal()) state.ports[key].enabled = !!(portCtrl & (1 << PORT_IDXS[key]));
            }
        }
        renderMemoryInfo(data);
        updateConnectionUI();
        renderAll();
    } catch (e) { console.error('API fetch error:', e); }
}

function updateConnectionUI() {
    const dot = document.getElementById('connectDot');
    const status = document.getElementById('connectStatus');
    const btn = document.getElementById('connectBtn');
    if (!dot || !status || !btn) return;
    if (state.bleConnected) {
        hideToast();
        dot.style.background = '#34C759';
        status.textContent = I18N.t('status.connected');
        status.style.color = 'var(--text)';
        btn.textContent = I18N.t('status.disconnect');
        btn.style.background = 'rgba(255,59,48,0.15)';
        btn.style.color = '#FF3B30';
    } else {
        dot.style.background = '#666';
        status.textContent = I18N.t('status.disconnected');
        status.style.color = 'var(--text-dim)';
        btn.textContent = I18N.t('status.connect');
        btn.style.background = 'rgba(255,255,255,0.1)';
        btn.style.color = 'var(--text)';
    }
}

function toast(msg, persist) {
    let el = document.getElementById('toast');
    if (!el) {
        el = document.createElement('div');
        el.id = 'toast';
        el.style.cssText = 'position:fixed;top:60px;left:50%;transform:translateX(-50%);z-index:999;background:rgba(0,0,0,0.85);color:#fff;padding:10px 20px;border-radius:20px;font-size:14px;pointer-events:none;transition:opacity 0.3s;opacity:0;white-space:nowrap;';
        document.body.appendChild(el);
    }
    clearTimeout(el._timer);
    el.textContent = msg;
    el.style.opacity = '1';
    if (!persist) el._timer = setTimeout(() => el.style.opacity = '0', 3000);
}
function hideToast() { const el = document.getElementById('toast'); if (el) el.style.opacity = '0'; }

async function toggleConnection() {
    const btn = document.getElementById('connectBtn');
    if (!btn || btn.disabled) return;
    btn.disabled = true;
    const enable = !state.bleConnected;
    btn.textContent = I18N.t(enable ? 'status.connecting' : 'status.disconnecting');
    if (enable) toast(I18N.t('toast.connecting'), true);
    markLocalChange();
    try {
        await fetch(`${API_BASE}/api/ble`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: enable }) });
        let start = Date.now();
        while (Date.now() - start < 30000) {
            await new Promise(r => setTimeout(r, 500));
            const res = await fetch(`${API_BASE}/api/all`);
            const data = await res.json();
            if ((data.connected && data.authenticated) === enable) break;
        }
        await fetchStatus();
    } catch(e) { console.error(e); }
    finally { btn.disabled = false; }
}

// ── Render ──
function renderAll() {
    renderDeviceArea();
    renderSceneCard();
    renderPortCtl();
    renderRateCard();
    renderCharts();
    renderPowerDist();
    renderDelayOff();
    renderSettingsUI();
    renderProtocolSwitches();
}
function renderDeviceArea() {
    let totalW = 0, hasAny = false;
    for (const [key, p] of Object.entries(state.ports)) {
        if (p.enabled && p.w > 0) { totalW += p.w; hasAny = true; }
    }

    const unconnectedImg = document.getElementById('unconnectedImg');
    const deviceContainer = document.getElementById('deviceContainer');
    const img = document.getElementById('deviceImg');
    const glow = document.getElementById('darkGlow');
    const badge = document.getElementById('sceneBadge');

    if (state.bleConnected) {
        unconnectedImg.classList.add('hidden');
        deviceContainer.classList.add('show');
        glow.classList.add('active');
        badge.classList.add('show');
        document.getElementById('sceneBadgeIcon').src = `static/main_card_scene_icon_${SCENE_IMAGES[state.scene]}.webp`;
        document.getElementById('sceneBadgeText').textContent = sceneName(state.scene);
        if (hasAny) {
            deviceContainer.classList.add('charging');
        } else {
            deviceContainer.classList.remove('charging');
        }
    } else {
        unconnectedImg.classList.remove('hidden');
        deviceContainer.classList.remove('show');
        deviceContainer.classList.remove('charging');
        glow.classList.remove('active');
        badge.classList.remove('show');
    }

    // USB overlay modules
    const modulePositions = { c1: 36, c2: 68, c3: 100, a: 133 };
    for (const [key, p] of Object.entries(state.ports)) {
        const mod = document.getElementById('usbModule' + key.toUpperCase());
        const powerEl = document.getElementById('usbPower' + key.toUpperCase());
        if (p.enabled && p.w > 0) {
            mod.classList.add('active');
            mod.style.top = modulePositions[key] + 'px';
            powerEl.textContent = p.w.toFixed(1) + 'W';
        } else {
            mod.classList.remove('active');
        }
    }
}

function renderSceneCard() {
    document.getElementById('sceneName').textContent = sceneName(state.scene);
    const desc = document.getElementById('sceneDesc');
    if (desc) desc.textContent = sceneDesc(state.scene);

    document.querySelectorAll('.scene-btn').forEach(btn => {
        const mode = parseInt(btn.dataset.mode);
        const active = mode === state.scene;
        btn.classList.toggle('active', active);
        const imgEl = document.getElementById('sceneImg' + mode);
        if (imgEl) {
            const imgName = SCENE_BTN_IMAGES[mode];
            const theme = isDark ? 'dark' : 'light';
            var newSrc = `static/main_charger_${theme}_${imgName}_${active ? 'on' : 'off'}.webp`;
            if (imgEl.src.indexOf(newSrc) < 0) imgEl.src = newSrc;
        }
    });
}

function renderPortCtl() {
    for (const key of PORT_KEYS) {
        const p = state.ports[key];
        const enabled = p.enabled !== false;
        const toggle = document.getElementById('toggle' + key.toUpperCase());
        if (toggle) toggle.checked = enabled;
        const icon = document.querySelector(`#toggle${key.toUpperCase()}`).closest('.port-ctl-item').querySelector('.port-ctl-port-icon img');
        if (icon) {
            icon.src = enabled
                ? `static/main_card_port_${key}_on.webp`
                : `static/main_card_port_${key}_off.webp`;
        }
    }
}

function renderRateCard() {
    let totalW = 0;
    for (const p of Object.values(state.ports)) {
        if (p.enabled) totalW += p.w;
    }
    document.getElementById('totalPowerNum').textContent = totalW.toFixed(1);

    // Check if C3+USB-A merged (0x11 = merged mode)
    const isMerged = state.ports.c3?.status_raw === 0x11;

    // Port power rows above each chart
    for (const key of PORT_KEYS) {
        const row = document.getElementById('portPower' + key.toUpperCase() + 'Row');
        if (!row) continue;

        if (key === 'a' && isMerged) {
            row.style.display = 'none';
            continue;
        }
        row.style.display = '';

        const p = state.ports[key];
        const enabled = state.ports[key].enabled;
        const w = enabled ? p.w : 0;
        const status = enabled && w > 0 ? w.toFixed(1) : '--';
        const protocol = enabled && p.protocol ? p.protocol : '';
        const name = (key === 'c3' && isMerged) ? 'C3&A' : PORT_NAMES[key];
        row.innerHTML = `<div class="port-power-row" style="margin-bottom:2px;">
            <div class="port-power-dot" style="background:${PORT_COLORS[key]}"></div>
            <span class="port-power-name">${name}</span>
            <span class="port-power-w">${status}</span>
            <span class="port-power-w-unit">W</span>
            <span class="port-power-protocol">${protocol}</span>
        </div>`;
    }
}

let portCharts = {};
function renderCharts() {
    let totalW = 0;
    // When BLE disconnected, chart shows 0 instead of stale data
    if (state.bleConnected) {
        for (const p of Object.values(state.ports)) {
            if (p.enabled) totalW += p.w;
        }
    }
    if (!state._totalHistory) state._totalHistory = [];
    if (totalW > 0 || state._totalHistory.length > 0) {
        state._totalHistory.push(totalW);
        if (state._totalHistory.length > 30) state._totalHistory.shift();
    }

    // Mini bar chart
    const miniChart = document.getElementById('miniChart');
    if (miniChart) {
        const maxVal = Math.max(1, ...state._totalHistory);
        let miniHtml = '';
        for (const v of state._totalHistory) {
            const h = Math.max(2, (v / maxVal) * 100);
            miniHtml += `<div class="mini-bar" style="height:${h}%;opacity:${v > 0 ? 1 : 0.3}"></div>`;
        }
        miniChart.innerHTML = miniHtml;
    }

    // Update port history — push 0 when disconnected
    let hasData = false;
    for (const key of PORT_KEYS) {
        const p = state.ports[key];
        if (state.bleConnected && p.enabled && p.w > 0) hasData = true;
    }
    if (hasData || state.history.c1.length > 0) {
        for (const key of PORT_KEYS) {
            const p = state.ports[key];
            const w = (state.bleConnected && p.enabled && p.w > 0) ? p.w : 0;
            state.history[key].push(w);
            if (state.history[key].length > 30) state.history[key].shift();
        }
    }

    // Combined chart: all 4 ports
    const combinedCanvas = document.getElementById('chartCombined');
    if (combinedCanvas && (portCharts.combined || typeof Chart !== 'undefined')) {
        // 计算动态峰值
        let currentPeak = 0;
        for (const key of PORT_KEYS) {
            for (const v of state.history[key]) {
                if (v > currentPeak) currentPeak = v;
            }
        }
        const peakPower = currentPeak > 0 ? currentPeak * 1.18 : 60;

        if (portCharts.combined) {
            // Update existing chart in place (no flicker)
            const chart = portCharts.combined;
            chart.data.labels = state.history.c1.map((_, i) => i);
            PORT_KEYS.forEach((key, i) => {
                chart.data.datasets[i].data = state.history[key];
            });
            chart.options.scales.y.max = peakPower;
            chart.update('none');
            chart._peakData = { peakPower, currentPeak, isDark };
            drawPeakLines(chart);
        } else {
            // First render: create chart
            portCharts.combined = new Chart(combinedCanvas, {
                type: 'line',
                data: {
                    labels: state.history.c1.map((_, i) => i),
                    datasets: PORT_KEYS.map(key => ({
                        label: PORT_NAMES[key],
                        data: state.history[key],
                        borderColor: PORT_COLORS[key],
                        borderWidth: 1.5,
                        tension: 0.4,
                        pointRadius: 0,
                        fill: false,
                    }))
                },
                options: {
                    responsive: true, maintainAspectRatio: false, animation: { duration: 300 },
                    interaction: { intersect: false, mode: 'index' },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { display: false },
                        y: { display: false, min: 0, max: peakPower },
                    }
                }
            });
            portCharts.combined._peakData = { peakPower, currentPeak, isDark };
            drawPeakLines(portCharts.combined);
        }
    }
}

function renderSettingsUI() {
    const st = document.getElementById('screenTimeVal');
    if (st) st.innerHTML = screenTimeLabel(state.screenTime) + ' <span style="font-size:10px;color:var(--text-dim);margin-left:4px;">&gt;</span>';
    const tt = document.getElementById('toggleTrickle');
    if (tt) tt.checked = state.trickleEnabled;
}

function renderProtocolSwitches() {
    const sw = state.protocolSwitches;
    if (!sw || Object.keys(sw).length === 0) return;
    const labels = { pd: 'PD', pps: 'PPS', ufcs: 'UFCS', scp: 'SCP' };
    for (const port of PORT_KEYS) {
        const ps = sw[port];
        const el = document.getElementById('portProtos_' + port);
        if (!el || !ps) continue;
        const protoKeys = Object.keys(ps);
        let html = '';
        for (const pk of protoKeys) {
            // PD 关闭时隐藏 PPS 按钮（硬件不支持）
            if ((port === 'c1' || port === 'c2') && pk === 'pps' && !sw[port].pd) continue;
            const on = ps[pk];
            html += `<button class="proto-btn ${on ? 'on' : ''}" data-port="${port}" data-proto="${pk}" onclick="phoneToggleProtocol(this)">${labels[pk] || pk}</button>`;
        }
        // C1/C2 提示 PD 与 PPS 关联，C3/A 提示需插拔
        if (port === 'c1' || port === 'c2') {
            html += '<div style="font-size:9px;color:var(--text-dim);margin-top:2px;flex-basis:100%;">' + I18N.t('proto.pdNote') + '</div>';
        } else {
            html += '<div style="font-size:9px;color:var(--text-dim);margin-top:2px;flex-basis:100%;">' + I18N.t('proto.replugNote') + '</div>';
        }
        el.innerHTML = html;
    }
}

async function phoneToggleProtocol(btn) {
    if (btn.disabled) return;
    btn.disabled = true;
    const port = btn.dataset.port;
    const proto = btn.dataset.proto;
    try {
        await fetch(`${API_BASE}/api/protocol`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ port, protocol: proto, action: btn.classList.contains('on') ? 'off' : 'on' })
        });
        // 乐观更新
        if (state.protocolSwitches[port]) state.protocolSwitches[port][proto] = !state.protocolSwitches[port][proto];
        renderProtocolSwitches();
    } catch (e) { console.error('Protocol toggle error:', e); }
    finally { btn.disabled = false; }
}

function renderPowerDist() {
    const bar = document.getElementById('powerDist');
    const text = document.getElementById('powerDistText');
    if (!bar || !text) return;
    let powers = [];
    let totalActive = 0;
    for (const key of PORT_KEYS) {
        const p = state.ports[key];
        const w = (state.ports[key].enabled && p.w > 0) ? p.w : 0;
        totalActive += w;
        powers.push({ key, name: PORT_NAMES[key], w, color: PORT_COLORS[key] });
    }
    const total = totalActive || 1;
    bar.innerHTML = powers.map(x => `<div style="width:${(x.w/total*100).toFixed(1)}%;height:100%;background:${x.color};transition:width 0.5s;"></div>`).join('');
    text.innerHTML = powers.map(x => {
        const pct = (x.w / total * 100).toFixed(0);
        return `<span style="color:${x.color};${x.w > 0 ? '' : 'opacity:0.3;'}">${x.name} ${pct}%</span>`;
    }).join('');
}

// ── Delay Off ──
const delayMinutes = { c1: 0, c2: 0, c3: 0, a: 0 };
const DELAY_PIIDS = { c1: 9, c2: 10, c3: 11, a: 12 };
function renderDelayOff() {
    const grid = document.getElementById('delayOffGrid');
    if (!grid) return;
    // Only show active ports (w > 0)
    const activeKeys = PORT_KEYS.filter(key => state.ports[key].v > 0);
    if (activeKeys.length === 0) { grid.innerHTML = '<div style="font-size:13px;color:var(--text-dim);text-align:center;padding:12px;">' + I18N.t('delay.noActivePorts') + '</div>'; return; }
    let html = '';
    activeKeys.forEach((key, idx) => {
        const min = delayMinutes[key] || 0;
        const dotColor = PORT_COLORS[key];
        const sliderId = `delaySlider_${key}`;
        html += `<div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <div style="width:10px;height:10px;border-radius:50%;background:${dotColor};flex-shrink:0;"></div>
                    <span style="font-size:15px;color:var(--text);">${PORT_NAMES[key]}</span>
                </div>
                <span id="delayVal_${key}" style="font-size:14px;font-weight:600;color:${min>0?dotColor:'var(--text-dim)'};">${min > 0 ? I18N.t('delay.minutes', {n: min}) : I18N.t('delay.none')}</span>
            </div>
            <input type="range" id="${sliderId}" min="0" max="240" value="${min}" step="1" class="delay-slider"
                style="background:linear-gradient(to right,${dotColor} ${min/240*100}%,rgba(255,255,255,0.08) ${min/240*100}%); --thumb-color:${dotColor};">
                <style>#${sliderId}::-webkit-slider-thumb{background:${dotColor}} #${sliderId}::-moz-range-thumb{background:${dotColor}}</style>
        </div>`;
        if (idx < activeKeys.length - 1) html += `<div style="height:1px;background:rgba(255,255,255,0.04);margin:18px 0;"></div>`;
    });
    grid.innerHTML = html;
    for (const key of activeKeys) {
        const slider = document.getElementById(`delaySlider_${key}`);
        if (slider) {
            slider.oninput = function() {
                const v = parseInt(this.value);
                delayMinutes[key] = v;
                const valEl = document.getElementById('delayVal_' + key);
                if (valEl) {
                    valEl.textContent = v > 0 ? I18N.t('delay.minutes', {n: v}) : I18N.t('delay.none');
                    valEl.style.color = v > 0 ? PORT_COLORS[key] : 'var(--text-dim)';
                }
                this.style.background = `linear-gradient(to right,${PORT_COLORS[key]} ${v/240*100}%,rgba(255,255,255,0.08) ${v/240*100}%)`;
            };
            slider.onchange = async function() {
                const v = parseInt(this.value);
                markLocalChange();
                try { await fetch(`${API_BASE}/api/setting`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ piid: DELAY_PIIDS[key], value: v }) }); } catch(e) {}
            };
        }
    }
}

// ── Actions ──
async function setScene(mode) {
    state.scene = mode;
    markLocalChange();
    renderAll();
    try {
        await fetch(`${API_BASE}/api/setting`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ piid: SCENE_PIID, value: mode }) });
    } catch(e) { console.error('setScene error:', e); }
}

async function togglePort(key) {
    const on = !state.ports[key].enabled;
    state.ports[key].enabled = on;
    markLocalChange();
    renderAll();
    try {
        await fetch(`${API_BASE}/api/port`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ port: key, action: on ? 'on' : 'off' }) });
    } catch(e) { console.error(e); }
}

async function toggleTrickle() {
    state.trickleEnabled = !state.trickleEnabled;
    markLocalChange();
    try { await fetch(`${API_BASE}/api/setting`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ piid: 15, value: state.trickleEnabled ? 1 : 0 }) }); } catch(e) {}
}

async function cycleScreenTime() {
    state.screenTime = ((state.screenTime - 1) % 5 + 6) % 5 + 1;
    document.getElementById('screenTimeVal').innerHTML =
        screenTimeLabel(state.screenTime) + ' <span style="font-size:10px;color:var(--text-dim);margin-left:4px;">&gt;</span>';
    markLocalChange();
    try { await fetch(`${API_BASE}/api/setting`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ piid: 6, value: state.screenTime }) }); } catch(e) {}
}

// ── Top-view fade on scroll ──
const topView = document.querySelector('.top-view');
function handleFade(scrollY) {
    if (topView) {
        var progress = Math.min(1, Math.max(0, (scrollY - 40) / 220));
        topView.style.opacity = (1 - progress).toFixed(3);
    }
}
const phone = document.querySelector('.phone');
if (phone) phone.addEventListener('scroll', () => handleFade(phone.scrollTop));
window.addEventListener('scroll', () => handleFade(window.scrollY));

// ── Theme Toggle ──
let isDark = localStorage.getItem('cuktech-theme') !== 'light';
if (!isDark) { document.body.classList.add('light'); var tb = document.getElementById('themeBtn'); if(tb) tb.textContent = '🌙'; }
function toggleTheme() {
    isDark = !isDark;
    localStorage.setItem('cuktech-theme', isDark ? 'dark' : 'light');
    document.body.classList.toggle('light', !isDark);
    document.querySelectorAll('img[src*="_dark_"], img[src*="_light_"]').forEach(function(i) { i.src = i.src.replace('_dark_', '_X_').replace('_light_', '_dark_').replace('_X_', '_light_'); });
    document.getElementById('themeBtn').textContent = isDark ? '☀️' : '🌙';
}

function renderMemoryInfo(data) {
    var el = document.getElementById('memInfo');
    if (!el) return;
    var free = data.free_heap || 0;
    var minFree = data.min_free_heap || 0;
    var maxBlock = data.max_block || 0;
    el.innerHTML = I18N.t('mem.label') + ': ' + (free/1024).toFixed(1) + 'K | ' + (maxBlock/1024).toFixed(1) + 'K | ' + (minFree/1024).toFixed(1) + 'K';
}

// ── Init ──
renderAll();
initPhoneSSE();
initChartLazyLoad();
// Chart decoupled from SSE — update every 2s instead of every ~1s push
setInterval(renderCharts, 2000);

// ── i18n: 语言切换后立即重渲染全部动态文案（无需刷新页面） ──
I18N.onChange(function () {
    updateConnectionUI();
    renderAll();
});

// ── Lazy chart library ──
// chart.umd.min.js is 70 KB and is only used by #chartCombined in the rate
// card, which starts below the fold.  Fetch it when that card is about to
// scroll into view so a cold load spends its bandwidth on images; the
// regular renderCharts() tick picks it up as soon as it has arrived.
let _chartLoading = false;
function loadChartLib() {
    if (_chartLoading || typeof Chart !== 'undefined') return;
    _chartLoading = true;
    const s = document.createElement('script');
    s.src = '/static/chart.umd.min.js';
    s.onload = function () { try { renderCharts(); } catch (e) {} };
    s.onerror = function () { _chartLoading = false; };
    document.head.appendChild(s);
}
function initChartLazyLoad() {
    const anchor = document.getElementById('chartCombined');
    if (!anchor) return;
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(function (entries) {
            for (let i = 0; i < entries.length; i++) {
                if (entries[i].isIntersecting) { io.disconnect(); loadChartLib(); return; }
            }
        }, { rootMargin: '300px' });
        io.observe(anchor);
    } else {
        window.addEventListener('load', function () { setTimeout(loadChartLib, 1000); });
    }
}

// ── Polling (ESP32 has no SSE) ──
// Self-scheduling: the next poll is only queued once the previous response
// has arrived.  A fixed 2 s interval piled up requests whenever the device
// was busy (a cold page load answered /api/all in 15-20 s), and every queued
// poll held one of the browser's six sockets per host, starving the images
// the page was waiting for.  Polling is also slowed down while the page is
// hidden so a backgrounded tab stops competing with a foreground one.
function initPhoneSSE() {
    (async function poll() {
        try { await fetchStatus(); } catch (e) { /* retried on the next tick */ }
        setTimeout(poll, document.hidden ? 10000 : 2000);
    })();
}

function applyFullStatus(data) {
    state.bleConnected = data.connected && data.authenticated;
    state.firmware = data.firmware_version || '';
    if (data.ports) {
        for (const [id, port] of Object.entries(data.ports)) {
            const key = API_PORT_MAP[id];
            if (key && state.ports[key]) {
                state.ports[key].v = port.voltage || 0;
                state.ports[key].a = port.current || 0;
                state.ports[key].w = port.power || 0;
                if (!isRecentLocal()) state.ports[key].enabled = port.enabled !== false;
                state.ports[key].protocol = port.protocol || 'idle';
            }
        }
    }
    if (data.protocol_switches) state.protocolSwitches = data.protocol_switches;
    if (data.protocol_extend !== undefined) state.protocolExtend = data.protocol_extend;
    if (data.settings) applySettingsUpdate(data.settings);
    updateConnectionUI();
    renderAll();
}

function applyPortUpdate(portId, portData) {
    const key = API_PORT_MAP[portId];
    if (!key || !state.ports[key]) return;
    state.ports[key].v = portData.voltage || 0;
    state.ports[key].a = portData.current || 0;
    state.ports[key].w = portData.power || 0;
    if (!isRecentLocal()) state.ports[key].enabled = portData.enabled !== false;
    state.ports[key].protocol = portData.protocol || 'idle';
    // Incremental render — skip chart (decoupled to 2s timer)
    renderDeviceArea();
    renderRateCard();
    renderPowerDist();
    renderDelayOff();
}

function applySettingsUpdate(settings) {
    state.settings = settings;
    const sceneVal = settings['5'];
    if (sceneVal && sceneVal > 0 && !isRecentLocal()) state.scene = sceneVal;
    if (!isRecentLocal()) {
        if (settings['6'] !== undefined) state.screenTime = settings['6'];
        if (settings['15'] !== undefined) state.trickleEnabled = settings['15'] === 1;
    }
    if (!isRecentLocal()) {
        for (const key of PORT_KEYS) {
            const v = settings[String(DELAY_PIIDS[key])];
            if (v !== undefined) delayMinutes[key] = parseInt(v) || 0;
        }
    }
    renderAll();
}

// ── Charge History ──
if (typeof startChargeHistoryAutoRefresh === 'function') {
    startChargeHistoryAutoRefresh('chargeSessionList', 'chargeStats', 'today', 2000);
}
